For Documention visit the api documentation url here
https://documenter.getpostman.com/view/7913131/2s93RNxuGU